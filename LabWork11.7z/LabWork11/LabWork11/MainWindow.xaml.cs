﻿using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Controls;

namespace LabWork11
{
    public partial class MainWindow : Window
    {
        private TcpListener? server;
        private bool isServerRunning = false;
        private ObservableCollection<ReceivedFile> receivedFiles = new();
        private string selectedFilePath = string.Empty;

        public class ReceivedFile
        {
            public string FileName { get; set; } = string.Empty;
            public string FilePath { get; set; } = string.Empty;
            public string Hash { get; set; } = string.Empty;
            public string Salt { get; set; } = string.Empty;
            public string HashAlgorithm { get; set; } = "SHA256";
            public bool Verified { get; set; } = false;
        }

        public MainWindow()
        {
            InitializeComponent();
            ReceivedFilesListBox.ItemsSource = receivedFiles;
        }

        private void BrowseFile_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                selectedFilePath = openFileDialog.FileName;
                FilePathTextBox.Text = selectedFilePath;
            }
        }

        private void UseSaltCheckBox_Changed(object sender, RoutedEventArgs e)
        {
            SaltPanel.Visibility = UseSaltCheckBox.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
        }

        private void GenerateSalt_Click(object sender, RoutedEventArgs e)
        {
            byte[] saltBytes = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(saltBytes);
            }
            SaltTextBox.Text = Convert.ToBase64String(saltBytes);
        }

        private void ComputeHash_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(selectedFilePath) || !File.Exists(selectedFilePath))
            {
                MessageBox.Show("Выберите файл для вычисления хэша.");
                return;
            }

            try
            {
                string algorithm = ((ComboBoxItem)HashAlgorithmComboBox.SelectedItem).Content.ToString()!;
                byte[] hash = ComputeFileHash(selectedFilePath, algorithm, UseSaltCheckBox.IsChecked == true ? SaltTextBox.Text : null);

                HashResultTextBox.Text = $"Алгоритм: {algorithm}\n";
                if (UseSaltCheckBox.IsChecked == true)
                {
                    HashResultTextBox.Text += $"Соль: {SaltTextBox.Text}\n";
                }
                HashResultTextBox.Text += $"Хэш: {BitConverter.ToString(hash).Replace("-", "").ToLower()}";

                SenderStatusText.Text = "Хэш успешно вычислен";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при вычислении хэша: {ex.Message}");
            }
        }

        private byte[] ComputeFileHash(string filePath, string algorithm, string? salt = null)
        {
            using (var stream = File.OpenRead(filePath))
            {
                HashAlgorithm hashAlgorithm = algorithm switch
                {
                    "SHA256" => SHA256.Create(),
                    "SHA512" => SHA512.Create(),
                    "MD5" => MD5.Create(),
                    _ => SHA256.Create()
                };

                using (hashAlgorithm)
                {
                    if (salt != null)
                    {
                        byte[] saltBytes = Convert.FromBase64String(salt);
                        byte[] fileBytes = File.ReadAllBytes(filePath);

                        // Комбинируем соль с данными файла
                        byte[] combined = new byte[saltBytes.Length + fileBytes.Length];
                        Buffer.BlockCopy(saltBytes, 0, combined, 0, saltBytes.Length);
                        Buffer.BlockCopy(fileBytes, 0, combined, saltBytes.Length, fileBytes.Length);

                        return hashAlgorithm.ComputeHash(combined);
                    }
                    else
                    {
                        return hashAlgorithm.ComputeHash(stream);
                    }
                }
            }
        }

        private async void SendFile_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(selectedFilePath) || !File.Exists(selectedFilePath))
            {
                MessageBox.Show("Выберите файл для отправки.");
                return;
            }

            try
            {
                string ip = IpAddressTextBox.Text;
                int port = int.Parse(PortTextBox.Text);

                string algorithm = ((ComboBoxItem)HashAlgorithmComboBox.SelectedItem).Content.ToString()!;
                string salt = UseSaltCheckBox.IsChecked == true ? SaltTextBox.Text : string.Empty;
                byte[] hash = ComputeFileHash(selectedFilePath, algorithm, salt);

                await SendFileAsync(selectedFilePath, ip, port, algorithm, hash, salt);

                SenderStatusText.Text = "Файл успешно отправлен";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отправке файла: {ex.Message}");
            }
        }

        private async Task SendFileAsync(string filePath, string ip, int port, string algorithm, byte[] hash, string salt)
        {
            using (var client = new TcpClient())
            {
                await client.ConnectAsync(ip, port);

                using (var stream = client.GetStream())
                using (var writer = new BinaryWriter(stream))
                {
                    // Отправляем метаданные
                    string fileName = Path.GetFileName(filePath);
                    writer.Write(fileName);
                    writer.Write(algorithm);
                    writer.Write(salt);
                    writer.Write(hash.Length);
                    writer.Write(hash);

                    // Отправляем файл
                    long fileSize = new FileInfo(filePath).Length;
                    writer.Write(fileSize);

                    using (var fileStream = File.OpenRead(filePath))
                    {
                        await fileStream.CopyToAsync(stream);
                    }
                }
            }
        }

        private async void StartServer_Click(object sender, RoutedEventArgs e)
        {
            if (isServerRunning) return;

            try
            {
                int port = int.Parse(ListenPortTextBox.Text);
                server = new TcpListener(IPAddress.Any, port);
                server.Start();
                isServerRunning = true;

                ReceiverStatusText.Text = "Сервер запущен. Ожидание подключений...";

                _ = Task.Run(async () => await ListenForClientsAsync());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка запуска сервера: {ex.Message}");
            }
        }

        private async Task ListenForClientsAsync()
        {
            while (isServerRunning && server != null)
            {
                try
                {
                    var client = await server.AcceptTcpClientAsync();
                    _ = Task.Run(async () => await HandleClientAsync(client));
                }
                catch (Exception ex)
                {
                    if (isServerRunning)
                        Dispatcher.Invoke(() => ReceiverStatusText.Text = $"Ошибка: {ex.Message}");
                }
            }
        }

        private async Task HandleClientAsync(TcpClient client)
        {
            try
            {
                using (client)
                using (var stream = client.GetStream())
                using (var reader = new BinaryReader(stream))
                {
                    // Читаем метаданные
                    string fileName = reader.ReadString();
                    string algorithm = reader.ReadString();
                    string salt = reader.ReadString();
                    int hashLength = reader.ReadInt32();
                    byte[] receivedHash = reader.ReadBytes(hashLength);
                    long fileSize = reader.ReadInt64();

                    // Сохраняем файл
                    string savePath = Path.Combine(Path.GetTempPath(), "ReceivedFiles", fileName);
                    Directory.CreateDirectory(Path.GetDirectoryName(savePath)!);

                    using (var fileStream = File.Create(savePath))
                    {
                        byte[] buffer = new byte[8192];
                        long totalRead = 0;

                        while (totalRead < fileSize)
                        {
                            int read = await stream.ReadAsync(buffer, 0, (int)Math.Min(buffer.Length, fileSize - totalRead));
                            await fileStream.WriteAsync(buffer, 0, read);
                            totalRead += read;
                        }
                    }

                    // Добавляем в список полученных файлов
                    Dispatcher.Invoke(() =>
                    {
                        receivedFiles.Add(new ReceivedFile
                        {
                            FileName = fileName,
                            FilePath = savePath,
                            Hash = BitConverter.ToString(receivedHash).Replace("-", ""),
                            Salt = salt,
                            HashAlgorithm = algorithm
                        });

                        ReceiverStatusText.Text = $"Получен файл: {fileName}";
                    });
                }
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() => ReceiverStatusText.Text = $"Ошибка обработки клиента: {ex.Message}");
            }
        }

        private void StopServer_Click(object sender, RoutedEventArgs e)
        {
            if (isServerRunning && server != null)
            {
                isServerRunning = false;
                server.Stop();
                ReceiverStatusText.Text = "Сервер остановлен";
            }
        }

        private void VerifyIntegrity_Click(object sender, RoutedEventArgs e)
        {
            var selectedFile = ReceivedFilesListBox.SelectedItem as ReceivedFile;
            if (selectedFile == null)
            {
                MessageBox.Show("Выберите файл для проверки.");
                return;
            }

            try
            {
                string? salt = string.IsNullOrEmpty(selectedFile.Salt) ? null : selectedFile.Salt;
                byte[] computedHash = ComputeFileHash(selectedFile.FilePath, selectedFile.HashAlgorithm, salt);
                string computedHashString = BitConverter.ToString(computedHash).Replace("-", "");

                bool isIntegrityValid = computedHashString.Equals(selectedFile.Hash, StringComparison.OrdinalIgnoreCase);
                selectedFile.Verified = isIntegrityValid;

                FileInfoTextBox.Text = $"Файл: {selectedFile.FileName}\n";
                FileInfoTextBox.Text += $"Алгоритм: {selectedFile.HashAlgorithm}\n";
                if (!string.IsNullOrEmpty(selectedFile.Salt))
                {
                    FileInfoTextBox.Text += $"Соль: {selectedFile.Salt}\n";
                }
                FileInfoTextBox.Text += $"Полученный хэш: {selectedFile.Hash}\n";
                FileInfoTextBox.Text += $"Вычисленный хэш: {computedHashString}\n";
                FileInfoTextBox.Text += $"Целостность: {(isIntegrityValid ? "✓ СОХРАНЕНА" : "✗ НАРУШЕНА")}";

                ReceiverStatusText.Text = isIntegrityValid ? "Целостность файла подтверждена" : "Нарушение целостности файла!";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при проверке целостности: {ex.Message}");
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            if (isServerRunning && server != null)
            {
                isServerRunning = false;
                server.Stop();
            }
            base.OnClosed(e);
        }
    }
}